package com.bancoADLS.springboot.app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BancoAdlsApplication {

	public static void main(String[] args) {
		SpringApplication.run(BancoAdlsApplication.class, args);
	}

}
